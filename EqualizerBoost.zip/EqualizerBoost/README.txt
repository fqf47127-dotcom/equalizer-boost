Cara membuka:
1. Install Android Studio (versi terbaru).
2. File > Open, pilih folder EqualizerBoost ini. Tunggu Gradle sync selesai.
3. Colok HP Android (aktifkan USB debugging) atau pakai emulator, lalu klik Run.
4. Untuk membuat file APK: Build > Build APK(s).
