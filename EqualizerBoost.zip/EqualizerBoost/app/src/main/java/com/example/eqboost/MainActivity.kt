package com.example.eqboost

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.*
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** 15 slider vertikal, -15 dB sampai +15 dB. */
class EqView(ctx: Context, private val values: FloatArray, private val onChange: () -> Unit) : View(ctx) {
    private val d = resources.displayMetrics.density
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#0A3A44"); strokeWidth = 3 * d; strokeCap = Paint.Cap.ROUND }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = CYAN; strokeWidth = 4 * d; strokeCap = Paint.Cap.ROUND }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = CYAN }
    private val area = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(70, 0, 207, 234) }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = 9.5f * d; textAlign = Paint.Align.CENTER }
    private val left = 34 * d
    private val top = 24 * d
    private fun bottom() = height - 44 * d
    private fun colW() = (width - left - 6 * d) / 15

    override fun onDraw(c: Canvas) {
        val bot = bottom(); val mid = (top + bot) / 2; val half = (bot - top) / 2; val cw = colW()
        c.drawText("+15", left / 2, top + 4 * d, txt); c.drawText("(dB)", left / 2, top + 16 * d, txt)
        c.drawText("0", left / 2, mid + 4 * d, txt); c.drawText("-15", left / 2, bot + 4 * d, txt)
        val xs = FloatArray(15) { left + cw * (it + 0.5f) }
        val ys = FloatArray(15) { mid - values[it] / 15f * half }
        for (i in 0 until 15) c.drawLine(xs[i], top, xs[i], bot, track)
        val p = Path().apply { moveTo(xs[0], mid); for (i in 0 until 15) lineTo(xs[i], ys[i]); lineTo(xs[14], mid); close() }
        c.drawPath(p, area)
        for (i in 0 until 15) {
            c.drawLine(xs[i], mid, xs[i], ys[i], line)
            c.drawCircle(xs[i], ys[i], 7.5f * d, dot)
            c.drawText(BAND_LABEL[i], xs[i], bot + 22 * d, txt)
        }
        c.drawText("Hz", left / 2, bot + 22 * d, txt)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        parent?.requestDisallowInterceptTouchEvent(true)
        if (e.actionMasked == MotionEvent.ACTION_DOWN || e.actionMasked == MotionEvent.ACTION_MOVE ||
            e.actionMasked == MotionEvent.ACTION_POINTER_DOWN) {
            val bot = bottom(); val mid = (top + bot) / 2; val half = (bot - top) / 2
            for (k in 0 until e.pointerCount) {
                val i = ((e.getX(k) - left) / colW()).toInt()
                if (i !in 0..14) continue
                var v = (mid - e.getY(k)) / half * 15f
                v = (v * 2).roundToInt() / 2f
                if (abs(v) < 0.6f) v = 0f
                values[i] = max(-15f, min(15f, v))
            }
            invalidate(); onChange()
        }
        return true
    }
}

class MainActivity : Activity() {
    private var player: MediaPlayer? = null
    private var playerSession = -1
    private lateinit var eqView: EqView
    private lateinit var songName: TextView
    private lateinit var playBtn: Button
    private lateinit var presetTxt: TextView
    private lateinit var status: TextView
    private val pickCode = 1
    private val ui = Handler(Looper.getMainLooper())

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        Fx.load(this)

        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)
        startForegroundService(Intent(this, EqService::class.java))

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#0A0A0A"))
            setPadding(dp(16), dp(20), dp(16), dp(24))
        }
        setContentView(ScrollView(this).apply { setBackgroundColor(Color.parseColor("#0A0A0A")); addView(root) })

        root.addView(Switch(this).apply {
            text = "EQ On"; textSize = 18f; setTypeface(null, Typeface.BOLD)
            setTextColor(Color.WHITE); isChecked = Fx.enabled
            setOnCheckedChangeListener { _, on -> Fx.enabled = on; Fx.update() }
        })

        status = TextView(this).apply { textSize = 12f; setTextColor(Color.parseColor("#8A9296")); setPadding(0, dp(6), 0, 0) }
        root.addView(status)
        root.addView(pillButton("Izinkan baterai penuh") {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        })

        val pr = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(10), 0, dp(6)) }
        presetTxt = TextView(this).apply {
            text = "Preset  ▾"; textSize = 18f; setTextColor(Color.WHITE); setTypeface(null, Typeface.BOLD)
            setOnClickListener { choosePreset() }
        }
        pr.addView(presetTxt, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        pr.addView(pillButton("SAVE") { saveCustom() })
        root.addView(pr)

        eqView = EqView(this, Fx.gains) { Fx.update() }
        root.addView(eqView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(330)))

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(10), dp(16), dp(16))
            background = GradientDrawable().apply { setColor(Color.parseColor("#0F0F0F")); cornerRadius = dp(24).toFloat() }
        }
        root.addView(card, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        row(card, "Pre-gain", 30, Fx.pre.toInt() + 15, { "${it - 15} dB" }) { Fx.pre = (it - 15).toFloat(); Fx.update() }
        row(card, "Balance", 24, Fx.bal.toInt() + 12, { val b = it - 12; if (b == 0) "0 dB" else if (b < 0) "L ${-b} dB" else "R $b dB" }) {
            Fx.bal = (it - 12).toFloat(); Fx.update()
        }
        row(card, "Output", 100, Fx.outPct, { "$it %" }) { Fx.outPct = it; Fx.update() }
        row(card, "Boost", 20, Fx.boostDb, { "+$it dB" }) { Fx.boostDb = it; Fx.update() }
        row(card, "Bass boost", 100, Fx.bassPct, { "$it %" }) { Fx.bassPct = it; Fx.update() }
        card.addView(TextView(this).apply {
            text = "Boost menambah volume sampai +20 dB. Di atas +10 dB suara bisa terlalu keras dan speaker bisa pecah. Naikkan pelan-pelan."
            textSize = 12f; setTextColor(Color.parseColor("#8A8A8A")); setPadding(0, dp(10), 0, 0)
        })

        songName = TextView(this).apply {
            text = "Pemutar uji: pilih lagu untuk mencoba efek di sini"; setTextColor(Color.WHITE); textSize = 14f
            setPadding(0, dp(18), 0, dp(8)); maxLines = 1
        }
        root.addView(songName)
        val pl = LinearLayout(this)
        pl.addView(pillButton("Pilih lagu") {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE); type = "audio/*"
            }, pickCode)
        })
        playBtn = pillButton("▶ Putar") { togglePlay() }.apply { isEnabled = false }
        pl.addView(playBtn)
        root.addView(pl)
    }

    override fun onResume() { super.onResume(); ui.postDelayed({ refreshStatus() }, 800) }
    override fun onPause() { Fx.save(this); super.onPause() }

    private fun refreshStatus() {
        status.text = if (Fx.globalOk)
            "Efek sistem aktif: berlaku untuk semua aplikasi. Biarkan notifikasi tetap menyala."
        else
            "Efek sistem tidak didukung HP ini. Efek tetap berlaku untuk Spotify dan pemutar lain yang mengirim sinyal efek audio, serta lagu di pemutar uji."
    }

    private fun pillButton(t: String, click: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; setTextColor(CYAN)
        background = GradientDrawable().apply { setColor(Color.BLACK); cornerRadius = dp(28).toFloat(); setStroke(dp(1), Color.parseColor("#0A3A44")) }
        setPadding(dp(22), 0, dp(22), 0)
        setOnClickListener { click() }
    }.also { it.layoutParams = LinearLayout.LayoutParams(-2, dp(46)).apply { rightMargin = dp(8) } }

    private fun row(parent: LinearLayout, label: String, maxV: Int, start: Int, fmt: (Int) -> String, on: (Int) -> Unit) {
        val r = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(8), 0, dp(8)) }
        r.addView(TextView(this).apply { text = label; textSize = 15f; setTextColor(Color.WHITE); setTypeface(null, Typeface.BOLD) },
            LinearLayout.LayoutParams(dp(96), -2))
        val v = TextView(this).apply { text = fmt(start); setTextColor(Color.WHITE); gravity = Gravity.END }
        val sb = SeekBar(this).apply {
            max = maxV; progress = start
            progressTintList = ColorStateList.valueOf(CYAN)
            thumbTintList = ColorStateList.valueOf(CYAN)
            progressBackgroundTintList = ColorStateList.valueOf(Color.parseColor("#0A3A44"))
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, u: Boolean) { v.text = fmt(p); if (u) on(p) }
                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) {}
            })
        }
        r.addView(sb, LinearLayout.LayoutParams(0, -2, 1f))
        r.addView(v, LinearLayout.LayoutParams(dp(64), -2))
        parent.addView(r)
    }

    private fun prefs() = getSharedPreferences("eq", MODE_PRIVATE)

    private fun choosePreset() {
        val names = PRESETS.keys.toMutableList()
        if (prefs().contains("custom")) names.add("Kustom")
        AlertDialog.Builder(this).setTitle("Pilih preset").setItems(names.toTypedArray()) { _, i ->
            val n = names[i]
            val src = if (n == "Kustom") prefs().getString("custom", "")!!.split(",").map { it.toFloat() }.toFloatArray() else PRESETS[n]!!
            src.copyInto(Fx.gains)
            presetTxt.text = "Preset: $n  ▾"
            eqView.invalidate(); Fx.update()
        }.show()
    }

    private fun saveCustom() {
        prefs().edit().putString("custom", Fx.gains.joinToString(",")).apply()
        presetTxt.text = "Preset: Kustom  ▾"
        Toast.makeText(this, "Preset kustom disimpan", Toast.LENGTH_SHORT).show()
    }

    // ---------- Pemutar uji ----------
    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (requestCode == pickCode && resultCode == RESULT_OK && uri != null) load(uri)
    }

    private fun load(uri: Uri) {
        releasePlayer()
        try {
            val mp = MediaPlayer().apply { setDataSource(this@MainActivity, uri); isLooping = true; prepare() }
            player = mp; playerSession = mp.audioSessionId
            if (!Fx.globalOk) Fx.attach(playerSession)
            songName.text = nameOf(uri)
            mp.start(); playBtn.isEnabled = true; playBtn.text = "⏸ Jeda"
        } catch (e: Exception) {
            Toast.makeText(this, "Gagal: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun nameOf(uri: Uri): String =
        contentResolver.query(uri, null, null, null, null)?.use {
            val i = it.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (it.moveToFirst() && i >= 0) it.getString(i) else null
        } ?: "Lagu terpilih"

    private fun togglePlay() {
        val mp = player ?: return
        if (mp.isPlaying) { mp.pause(); playBtn.text = "▶ Putar" } else { mp.start(); playBtn.text = "⏸ Jeda" }
    }

    private fun releasePlayer() {
        if (playerSession > 0) Fx.detach(playerSession)
        player?.release(); player = null; playerSession = -1
    }

    override fun onDestroy() { releasePlayer(); super.onDestroy() }
}
