package com.example.eqboost

import android.content.Context
import android.graphics.Color
import android.media.audiofx.BassBoost
import android.media.audiofx.DynamicsProcessing
import android.media.audiofx.LoudnessEnhancer
import kotlin.math.log10
import kotlin.math.max

val CYAN: Int = Color.parseColor("#00CFEA")
val BAND_HZ = floatArrayOf(30f, 60f, 200f, 300f, 360f, 470f, 730f, 1200f, 1800f, 2900f, 4800f, 7000f, 11000f, 15000f, 19000f)
val BAND_LABEL = arrayOf("30", "60", "200", "300", "360", "470", "730", "1.2k", "1.8k", "2.9k", "4.8k", "7k", "11k", "15k", "19k")
val PRESETS = linkedMapOf(
    "Flat" to FloatArray(15),
    "Bass Boost" to floatArrayOf(8f, 8f, 7f, 6f, 4f, 2f, 1f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f),
    "Vokal" to floatArrayOf(-3f, -2f, -1f, 0f, 0f, 1f, 2f, 3f, 4f, 4f, 3f, 2f, 0f, -1f, -2f),
    "Treble" to floatArrayOf(0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 1f, 2f, 3f, 5f, 6f, 7f, 7f),
    "Loud" to floatArrayOf(7f, 6f, 4f, 2f, 0f, -1f, -1f, 0f, 0f, 1f, 3f, 4f, 5f, 6f, 6f)
)

/** Pengaturan + efek audio. Satu rantai efek per sesi audio (0 = efek global seluruh sistem). */
object Fx {
    val gains = FloatArray(15)
    var enabled = true
    var pre = 0f          // dB
    var bal = 0f          // -12 kiri .. +12 kanan
    var outPct = 100
    var boostDb = 0
    var bassPct = 0
    var globalOk = false  // true jika efek sesi 0 (semua aplikasi) berhasil dipasang

    private class Chain(val dp: DynamicsProcessing?, val bass: BassBoost?, val loud: LoudnessEnhancer?)
    private val chains = HashMap<Int, Chain>()

    @Synchronized
    fun attach(session: Int): Boolean {
        if (chains.containsKey(session)) { update(); return true }
        var d: DynamicsProcessing? = null
        try {
            val cfg = DynamicsProcessing.Config.Builder(
                DynamicsProcessing.VARIANT_FAVOR_FREQUENCY_RESOLUTION, 2, true, 15, false, 0, false, 0, true
            ).build()
            d = DynamicsProcessing(0, session, cfg)
        } catch (_: Throwable) {}
        val b = try { BassBoost(0, session) } catch (_: Throwable) { null }
        val l = try { LoudnessEnhancer(session) } catch (_: Throwable) { null }
        if (d == null && b == null && l == null) return false
        val c = Chain(d, b, l)
        chains[session] = c
        apply(c)
        if (session == 0 && d != null) globalOk = true
        return true
    }

    @Synchronized
    fun detach(session: Int) {
        val c = chains.remove(session) ?: return
        try { c.dp?.release() } catch (_: Throwable) {}
        try { c.bass?.release() } catch (_: Throwable) {}
        try { c.loud?.release() } catch (_: Throwable) {}
        if (session == 0) globalOk = false
    }

    @Synchronized
    fun update() { chains.values.forEach { apply(it) } }

    private fun apply(c: Chain) {
        c.dp?.let { d ->
            try {
                for (i in 0 until 15) d.setPreEqBandAllChannelsTo(i, DynamicsProcessing.EqBand(true, BAND_HZ[i], gains[i]))
                d.setInputGainbyChannel(0, pre - max(0f, bal))
                d.setInputGainbyChannel(1, pre - max(0f, -bal))
                val post = if (outPct <= 0) -80f else 20f * log10(outPct / 100f)
                for (ch in 0..1) d.setLimiterByChannelIndex(ch, DynamicsProcessing.Limiter(true, true, 0, 1f, 60f, 10f, -1f, post))
                d.enabled = enabled
            } catch (_: Throwable) {}
        }
        try { c.loud?.setTargetGain(boostDb * 100); c.loud?.enabled = enabled } catch (_: Throwable) {}
        try { c.bass?.setStrength((bassPct * 10).toShort()); c.bass?.enabled = enabled } catch (_: Throwable) {}
    }

    fun load(c: Context) {
        val s = c.getSharedPreferences("eq", Context.MODE_PRIVATE).getString("state", null) ?: return
        try {
            val p = s.split("|")
            enabled = p[0] == "1"; pre = p[1].toFloat(); bal = p[2].toFloat(); outPct = p[3].toInt()
            boostDb = p[4].toInt(); bassPct = p[5].toInt()
            p[6].split(",").forEachIndexed { i, v -> gains[i] = v.toFloat() }
        } catch (_: Exception) {}
    }

    fun save(c: Context) {
        c.getSharedPreferences("eq", Context.MODE_PRIVATE).edit()
            .putString("state", "${if (enabled) 1 else 0}|$pre|$bal|$outPct|$boostDb|$bassPct|${gains.joinToString(",")}").apply()
    }
}
